import socket,threading

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("127.0.0.1", 5999))

def recv():
    while True:
        data, addr = sock.recvfrom(1024)
        print(addr, data.decode('utf-8'))

threading.Thread(target=recv, daemon=True).start()

while True:
    t = input(":").split(" ")
    try:
        sock.sendto(t[1].encode("utf-8"), (t[0].split(":")[0], int(t[0].split(":")[1])))
    except Exception as e:
        print(e)