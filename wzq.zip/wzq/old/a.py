# 导入 tkinter 和 tkinter.messagebox 模块
import tkinter as tk
import tkinter.messagebox as tkmsgbox

# 游戏逻辑
class Game:
    def __init__(self):
        self.board = [[' ' for _ in range(15)] for _ in range(15)]  # 初始化棋盘，使用二维列表表示
        self.current_player = 'X'  # 当前玩家，默认为 'X'

    def make_move(self, row, col):
        if self.board[row][col] == ' ':
            self.board[row][col] = self.current_player  # 在指定位置落子
            return True
        return False

    def switch_player(self):
        self.current_player = 'O' if self.current_player == 'X' else 'X'  # 切换玩家

    def check_win(self, row, col):
        directions = [(0, 1), (1, 0), (1, 1), (-1, 1)]  # 四个方向：水平、垂直、对角线、反对角线
        for dr, dc in directions:
            count = 1
            r, c = row, col
            while count < 5:
                r += dr
                c += dc
                if r < 0 or r >= 15 or c < 0 or c >= 15 or self.board[r][c] != self.current_player:
                    break
                count += 1
            r, c = row, col
            while count < 5:
                r -= dr
                c -= dc
                if r < 0 or r >= 15 or c < 0 or c >= 15 or self.board[r][c] != self.current_player:
                    break
                count += 1
            if count >= 5:
                return True
        return False

# 游戏界面
class GameGUI:
    def __init__(self, root):
        self.root = root
        self.game = Game()  # 创建游戏实例
        self.buttons = []  # 存储按钮的二维列表

        self.create_board()  # 创建游戏棋盘

    def create_board(self):
        for row in range(15):
            button_row = []
            for col in range(15):
                # 创建按钮，并绑定点击事件，使用 lambda 表达式传递行和列的值
                button = tk.Button(self.root, text='', width=2, height=1, command=lambda r=row, c=col: self.make_move(r, c))
                button.grid(row=row, column=col)  # 将按钮放置在游戏窗口的对应行列位置
                button_row.append(button)
            self.buttons.append(button_row)

    def make_move(self, row, col):
        if self.game.make_move(row, col):
            self.buttons[row][col].config(text=self.game.current_player)  # 在按钮上显示当前玩家的符号
            if self.game.check_win(row, col):
                winner = self.game.current_player
                tkmsgbox.showinfo("游戏结束", f"获胜者：{winner}")  # 弹出获胜者信息框
                self.reset_game()  # 重置游戏
            else:
                self.game.switch_player()  # 切换玩家

    def reset_game(self):
        self.game = Game()  # 创建新的游戏实例
        for row in self.buttons:
            for button in row:
                button.config(text='')  # 清空按钮上的文本

# 创建游戏窗口
root = tk.Tk()
root.title("五子棋")
game_gui = GameGUI(root)  # 创建游戏界面实例

# 运行游戏
root.mainloop()
