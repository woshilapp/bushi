import socket,threading,time

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("0.0.0.0", 5999))

client = {} #addr: player

# 游戏逻辑
class Game:
    def __init__(self):
        self.board = [[' ' for _ in range(15)] for _ in range(15)]  # 初始化棋盘，使用二维列表表示
        self.current_player = 'X'  # 当前玩家，默认为 'X'

    def make_move(self, row, col):
        if self.board[row][col] == ' ':
            self.board[row][col] = self.current_player  # 在指定位置落子
            return True
        return False

    def switch_player(self):
        self.current_player = 'O' if self.current_player == 'X' else 'X'  # 切换玩家

    def check_win(self, row, col):
        directions = [(0, 1), (1, 0), (1, 1), (-1, 1)]  # 四个方向：水平、垂直、对角线、反对角线
        for dr, dc in directions:
            count = 1
            r, c = row, col
            while count < 5:
                r += dr
                c += dc
                if r < 0 or r >= 15 or c < 0 or c >= 15 or self.board[r][c] != self.current_player:
                    break
                count += 1
            r, c = row, col
            while count < 5:
                r -= dr
                c -= dc
                if r < 0 or r >= 15 or c < 0 or c >= 15 or self.board[r][c] != self.current_player:
                    break
                count += 1
            if count >= 5:
                return True
        return False

def reset():
    global game,client
    game = Game()
    client = {}

def recv():
    while True:
        data, addr = sock.recvfrom(1024)
        data = data.decode('utf-8').split('||')

        if data[0] == "0":
            if len(client.keys()) < 2:
                if "X" in client.values():
                    client[addr] = "O"
                    sock.sendto("10||O".encode('utf-8'), addr)
                    print(f"{addr} is O")
                else:    
                    client[addr] = "X"
                    sock.sendto("10||X".encode('utf-8'), addr)
                    print(f"{addr} is X")
            else:
                pass
        elif data[0] == "1":
            if game.current_player != data[3] or len(client.keys()) < 2:
                sock.sendto("13".encode('utf-8'), addr)
            else:
                if game.make_move(int(data[1]), int(data[2])):
                    if game.check_win(int(data[1]), int(data[2])):
                        for a in client.keys():
                            sock.sendto(f"11||{data[1]}||{data[2]}||{data[3]}".encode('utf-8'), a)
                            sock.sendto(f"12||{game.current_player}".encode('utf-8'), a)
                        reset()
                        print(f"{game.current_player} win")
                    else:
                        print(f"{game.current_player} down {data[1]},{data[2]}")
                        game.switch_player()
                        for a in client.keys():
                            sock.sendto(f"11||{data[1]}||{data[2]}||{data[3]}".encode('utf-8'), a)
                else:
                    sock.sendto("13".encode('utf-8'), addr)

game = Game()

threading.Thread(target=recv, daemon=True).start()

while True:
    time.sleep(1) #dont exit
