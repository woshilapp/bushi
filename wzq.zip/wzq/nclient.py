import tkinter as tk
import socket,threading
from tkinter import messagebox as tkmsgbox

board = []
pl = ""
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

serverip = "0.0.0.0"
serverport = 5999

# 初始化棋盘
def init_board():
    global board
    board = [['' for _ in range(15)] for _ in range(15)]


# 绘制棋盘
def draw_board():
    canvas.delete("all")
    for i in range(15):
        canvas.create_line(20, 20 + i * 30, 440, 20 + i * 30)
        canvas.create_line(20 + i * 30, 20, 20 + i * 30, 440)
    for i in range(15):
        for j in range(15):
            if board[i][j] == 'B':
                canvas.create_oval(20 + j * 30 - 13, 20 + i * 30 - 13, 20 + j * 30 + 13, 20 + i * 30 + 13, fill='black')
            elif board[i][j] == 'W':
                canvas.create_oval(20 + j * 30 - 13, 20 + i * 30 - 13, 20 + j * 30 + 13, 20 + i * 30 + 13, fill='white')


# 绘制落子位置提示
def draw_placement_hint(x, y):
    radius = 10  # 半径调整为更小的值
    canvas.create_oval(20 + x * 30 - radius, 20 + y * 30 - radius, 20 + x * 30 + radius, 20 + y * 30 + radius,
                       fill='gray', outline='gray', tags='hint')


# 移除落子位置提示
def remove_placement_hint():
    canvas.delete('hint')


# 落子
def place_piece(event):
    global pl
    x, y = (event.x - 5) // 30, (event.y - 5) // 30
    send_dict(x, y, pl)

    print(x, y) #debug

# 鼠标移动事件处理函数
def mouse_motion(event):
    x, y = (event.x - 5) // 30, (event.y - 5) // 30
    if 0 <= x < 15 and 0 <= y < 15 and board[y][x] == '':
        remove_placement_hint()  # 清除之前的提示
        draw_placement_hint(x, y)  # 绘制新的提示


def make_move(r, c, pl):
    board[c][r] = pl
    draw_board()
    if pl == "B":
        label.config(text='当前玩家: 白')
    else:
        label.config(text='当前玩家: 黑')

def send_dict(row, col, text):
        sock.sendto(f"1||{row}||{col}||{text}".encode('utf-8'), (serverip, serverport))

def show_win(text):
    if text == "B":
        text = "黑"
    else:
        text = "白"
    tkmsgbox.showinfo("游戏结束", f"获胜者：{text}")  # 弹出获胜者信息框
    reset_game()  # 重置游戏

def show_chess(text):
    if text == "B":
        text = "黑"
    else:
        text = "白"
    root.title(f"五子棋: {text}")
    tkmsgbox.showinfo("您的棋子", f"您是：{text}")

def show_warn():
    tkmsgbox.showwarning("警告", "您不能下棋")  # 弹出获胜者信息框

def reset_game():
    # self.game = Game()  # 创建新的游戏实例
    label.config(text="当前玩家: 黑")
    sock.sendto("0".encode('utf-8'), (serverip, serverport))
    init_board()
    draw_board()


def recvth():
    global pl

    while True:
        try:
            data, addr = sock.recvfrom(1024)
            data = data.decode('utf-8').split('||')
            print(data) #.decode('utf-8').split('||')

            if data[0] == "10":
                pl = data[1]
                show_chess(data[1])
            elif data[0] == "11":
                make_move(int(data[1]), int(data[2]), data[3])
            elif data[0] == "12":
                show_win(data[1])
            elif data[0] == "13":
                show_warn()
        except Exception as e:
            print(e)

# 创建主窗口
root = tk.Tk()
root.title('五子棋')
root.resizable(False, False)

# 创建画布
canvas = tk.Canvas(root, width=460, height=460)
canvas.pack()

# 初始化棋盘
init_board()

# 绘制初始棋盘
draw_board()

# 绑定鼠标点击事件
canvas.bind("<Button-1>", place_piece)

# 绑定鼠标移动事件
canvas.bind("<Motion>", mouse_motion)

# 创建标签显示当前玩家
label = tk.Label(root, text='当前玩家: 黑')
label.pack()

sock.sendto("0".encode('utf-8'), (serverip, serverport))
threading.Thread(target=recvth, daemon=True).start()

# 启动主循环
root.mainloop()