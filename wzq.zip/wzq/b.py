import tkinter as tk
from tkinter import messagebox

board = []
current_player = ""


# 初始化棋盘
def init_board():
    global board, current_player
    board = [['' for _ in range(15)] for _ in range(15)]
    current_player = '黑'


# 绘制棋盘
def draw_board():
    canvas.delete("all")
    for i in range(15):
        canvas.create_line(20, 20 + i * 30, 440, 20 + i * 30)
        canvas.create_line(20 + i * 30, 20, 20 + i * 30, 440)
    for i in range(15):
        for j in range(15):
            if board[i][j] == '黑':
                canvas.create_oval(20 + j * 30 - 13, 20 + i * 30 - 13, 20 + j * 30 + 13, 20 + i * 30 + 13, fill='black')
            elif board[i][j] == '白':
                canvas.create_oval(20 + j * 30 - 13, 20 + i * 30 - 13, 20 + j * 30 + 13, 20 + i * 30 + 13, fill='white')


# 绘制落子位置提示
def draw_placement_hint(x, y):
    radius = 10  # 半径调整为更小的值
    canvas.create_oval(20 + x * 30 - radius, 20 + y * 30 - radius, 20 + x * 30 + radius, 20 + y * 30 + radius,
                       fill='gray', outline='gray', tags='hint')


# 移除落子位置提示
def remove_placement_hint():
    canvas.delete('hint')


# 落子
def place_piece(event):
    global current_player
    x, y = (event.x - 5) // 30, (event.y - 5) // 30
    if board[y][x] == '':
        board[y][x] = current_player
        draw_board()
        if check_win(x, y):
            messagebox.showinfo('游戏结束', f'{current_player}玩家获胜！')
            init_board()
        else:
            current_player = '白' if current_player == '黑' else '黑'
            label.config(text=f'当前玩家: {current_player}')
    print(x, y) #debug


# 检查是否获胜
def check_win(x, y):
    directions = [(1, 0), (0, 1), (1, 1), (1, -1)]
    for dx, dy in directions:  # 搜索与回溯
        count = 1
        for i in range(1, 5):
            nx, ny = x + i * dx, y + i * dy
            if 0 <= nx < 15 and 0 <= ny < 15 and board[ny][nx] == current_player:
                count += 1
            else:
                break
        for i in range(1, 5):
            nx, ny = x - i * dx, y - i * dy
            if 0 <= nx < 15 and 0 <= ny < 15 and board[ny][nx] == current_player:
                count += 1
            else:
                break
        if count >= 5:
            return True
    return False


# 鼠标移动事件处理函数
def mouse_motion(event):
    x, y = (event.x - 5) // 30, (event.y - 5) // 30
    if 0 <= x < 15 and 0 <= y < 15 and board[y][x] == '':
        remove_placement_hint()  # 清除之前的提示
        draw_placement_hint(x, y)  # 绘制新的提示


# 创建主窗口
root = tk.Tk()
root.title('五子棋')

# 创建画布
canvas = tk.Canvas(root, width=460, height=460)
canvas.pack()

# 初始化棋盘
init_board()

# 绘制初始棋盘
draw_board()

# 绑定鼠标点击事件
canvas.bind("<Button-1>", place_piece)

# 绑定鼠标移动事件
canvas.bind("<Motion>", mouse_motion)

# 创建标签显示当前玩家
label = tk.Label(root, text=f'当前玩家: {current_player}')
label.pack()

# 启动主循环
root.mainloop()
