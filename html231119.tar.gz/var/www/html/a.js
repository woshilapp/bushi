function fetchWithCredentials(url, method = 'GET', data = null, headers = {}) {
  // 设置基本的fetch选项
  let options = {
    method: method, // 请求方法
    credentials: 'same-origin', // 带上同源站点的Cookie
    headers: { // 设置默认的headers
      'Content-Type': 'application/json', // 假设发送的是JSON数据
      ...headers // 允许覆盖或增加新的headers
    },
  };

  // 如果是POST请求并且有数据，将数据添加到请求体中
  if (method === 'POST' && data) {
    options.body = JSON.stringify(data);
  }

  return fetch(url, options)
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.text(); // 根据响应内容修改，可能是response.text(), response.blob(), 等等
    })
    .catch(error => console.error('Fetch error:', error));
}
