<?php

require "./src/functions.php"; //import

session_start();

ini_set('session.gc_maxlifetime', 43200); // session time out half day

$www_root = "/var/www/html";//www folder
$root_dir = substr(__DIR__,strlen($www_root));//index.php path
// 获取当前请求的路径
$path = explode("?",$_SERVER['REQUEST_URI'])[0];

$token_pass = $_SESSION["pass"];

if (!$token_pass or !isset($_SESSION["pass"])) {
    echo "pass: " . $_SESSION["pass"] . "<br />";
    echo "not pass";
    return 0;
}

if (in_array_num(explode("/",$path),"src") === 1 or in_array_num(explode("/",$path),"data")) {
    die("illegit route"); //dont let user visit this directory    
}

// return 0; //so cool it make code stop

if (stristr($path,"index.php")) {
    $file = ".". substr($path,strlen($root_dir)+10) . '.php';
}
else {
    $file = ".". substr($path,strlen($root_dir)) . '.php';
}

// 构建 PHP 文件路径
// 或许有路径穿越漏洞，自行更改服务器配置修复，建议使用apache2.4以上版本

// 检查文件是否存在
if (file_exists($file)) {
    // 包含对应的 PHP 文件
    require $file;
} 
else {
    // 未匹配到任何路径的处理逻辑
    echo "Not Found" . "<br />";
    echo "Filename: ". $file . "<br />";
    // echo $_SERVER['PHP_SELF'] . "<br />";
    // echo $root_dir;
}
?>