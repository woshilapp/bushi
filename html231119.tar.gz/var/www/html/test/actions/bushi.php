<?php
    //the most important code

    /*
    input:
        array(
            ["g"] : bgroup
        )
    file:
        bsiterator:
            ["ng"] : next group,
            ["nc"] : next coins
    */

    require_once "./src/manager.php";
    require_once "./src/logmanager.php";
    require_once "./src/groupmanager.php";

    $m = new Manager();
    $lm = new LogManager();
    $gm = new GroupManager();

    if ($_SESSION["per"] != 2 and $_SESSION["per"] != 3) {
        die("permission denied");
    }

    $fpath = array("b"=>"./data/bsiterator", "t"=>"./data/ttgroup");
    
    if (file_get_contents($fpath["b"]) == "") {
        file_put_contents($fpath["b"], serialize(array("ng"=>0, "nc"=>3)));
    } else if (file_get_contents($fpath["t"]) == "") {
        file_put_contents($fpath["t"], serialize(array()));
    }
    
    $bsiter = unserialize(file_get_contents($fpath["b"]));
    $ttg = unserialize(file_get_contents($fpath["t"]));

    if ($_SESSION["per"] != 2 and $_SESSION["per"] != 3) {
        die("permission denied");
    }

    $data = (array)json_decode(file_get_contents("php://input"));
    if ($data == NULL) {
        die(json_encode($bsiter));
    }

    
    
?>