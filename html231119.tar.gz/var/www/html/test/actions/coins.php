<?php
    /* 
    input data:
        array(
            ["g"] : cgroup,
            ["b"] : bgroup,
            ["c"] : coins
        )
    */

    require_once "./src/groupmanager.php";
    require_once "./src/logmanager.php";

    $gm = new GroupManager();
    $lm = new LogManager();

    $data = (array)json_decode(file_get_contents("php://input"));
    if ($data === NULL) {
        die("no args or json error");
    }

    if ($_SESSION["per"] != 1 and $_SESSION["per"] != 3) {
        var_dump($_SESSION["per"]);
        echo "permission denied";
    } else if ($_SESSION["per"] == 1) {
        if ($data["g"] != $_SESSION["gp"]) {
            echo "not your group";
        } else {
            if ($gm->get_coin($_SESSION["gp"]) < $data["c"]) {
                echo "less than coin";
                return 0;
            }
            $gm->add_coin($data["b"], $data["c"]);
            $gm->reduce_coin($_SESSION["gp"], $data["c"]);
            echo "TRUE";
        }
    } else {
        if ($gm->get_coin($data["g"]) < $data["c"]) {
                echo "less than coin";
                return 0;
        } else {
            $gm->add_coin($data["b"], $data["c"]);
            $gm->reduce_coin($data["g"], $data["c"]);
            echo "TRUE";
        }
    }
?>