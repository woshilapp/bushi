<?php
require "./src/mysql.php";
$sql = "SELECT * FROM Basic";
$mysql = new Database;
if ($mysql->connerr !== TRUE) {
    echo "connected" . "<br>";
}
$result = $mysql->query($sql);
// echo var_dump($result);

if ($result instanceof mysqli_result) {
    while($row = $result->fetch_assoc()) {
        // echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
        echo "id: " . $row["id"]. " name:" . $row["name"] . " value:" . $row["value"] . "<br>";
    }
} else {
    if($result["err"] === TRUE) {
        die("error: " . $result["msg"]);
    }
}
?>