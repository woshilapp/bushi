<!DOCTYPE html>
<html>
<head>
    <title>json test</title>
    <meta charset="utf-8">
</head>
<body>
<?php

require_once "./src/functions.php";

// $fpath = "./data/user.json";
// $f = fopen($fpath,"r") or "er";
// if($f == "er"){
//     echo "<h1>Unable to access file</h1>";
// }
// else{
//     $str = fread($f,filesize($fpath));
//     // echo $str;
//     echo "<h1>",var_dump(json_decode($str)),"</h1><br />";
//     echo "<h1>",var_dump((array)json_decode($str)),"</h1>";
// }

// $arr = [1,1,2,3,4,4,5,6];
// $narr = pop_array_val($arr, 4);

// echo "arr: " . var_dump($arr) . " narr: " . var_dump($narr);

// $arr = ["1","1","3","7","4","2","10"];
// sort($arr);
// var_dump($arr);

var_dump(json_decode("sssssb"));

?>
</body>
</html>