<?php
session_start();
// 存储 session 数据
// $_SESSION['views']=1;
?>
 
<html>
<head>
<meta charset="utf-8">
<title>test</title>
</head>
<body>
 
<?php
if(isset($_SESSION['views']))
{
    $_SESSION['views']=$_SESSION['views']+1;
}
else
{
    $_SESSION['views']=1;
}
echo "浏览量：". $_SESSION['views']. "<br />";
echo "success login";
// echo substr("sbbbbbbbb",4);
// echo (int)"sb112233"; //0
// echo (int)"112233"; //112233
?>
 
</body>
</html>