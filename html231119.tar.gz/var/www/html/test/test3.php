<?php
    // echo var_dump($_GET) . "<br>";
    // // echo var_dump($HTTP_RAW_POST_DATA);
    // echo file_get_contents("php://input");
    require "./src/groupmanager.php";
    require_once "./src/logmanager.php";
    require_once "./src/manager.php";
    $a = new LogManager();
    $b = new GroupManager();
    $c = new Manager();
    // echo var_dump($c->set_sum(0)) . "<br>";
    // echo var_dump($c->set_round(0));
    // echo var_dump($b->reduce_coin(1,5));
    // var_dump($a->get_logs(3));
    var_dump($a->new_log(3, 2, 1, 114514, "None"));
    // $b->gen_cards();
?>