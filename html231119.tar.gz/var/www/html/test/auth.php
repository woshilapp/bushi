<?php
session_start();

$fpath = "./data/user.json";
$f = fopen($fpath,"r") or "er"; //read file

if($f == "er"){
    die("error while reading file");
}

$jsontext = fread($f,filesize($fpath));
$json = (array)json_decode($jsontext); //decode json

if ($_GET["t"]) {
    if ($_GET["t"] === "l") {
        $ltext = (array)json_decode(file_get_contents("php://input"));
        if (array_key_exists($ltext["u"],$json)) { //check user exist
            if ($ltext["p"]==$json[$ltext["u"]][0]) { //check password
                if (isset($_SESSION["pass"])) {
                    session_destroy();
                    session_start();
                }
                if ($json[$ltext["u"]][1] === 1) {
                    $_SESSION["pass"] = TRUE;
                    $_SESSION["per"] = $json[$ltext["u"]][1];
                    $_SESSION["gp"] = $json[$ltext["u"]][2];
                    echo "Pass: " . $_SESSION["pass"] . "<br>";
                    echo $_SESSION["per"] . "<br>";
                    echo $_SESSION["gp"];
                } else {
                    $_SESSION["pass"] = TRUE;
                    $_SESSION["per"] = $json[$ltext["u"]][1];
                    echo "Pass: " . $_SESSION["pass"] . "<br>";
                    echo $_SESSION["per"];
                }
            } else {
                echo "password incorrect";
            }
        }
        
        else {
            // echo var_dump(isset($json[$ltext["u"]])) . "<br />";
            // echo var_dump($ltext["u"]) . "<br />";
            // echo var_dump($json) . "<br />";
            // ^ debug code
            echo "user not found";
        }
    } else if ($_GET["t"] === "o") {
        echo "logout";
        session_destroy();
        return 0;   
    } else {
        die("arg illegit");
    }
} else {
    echo "no args";
}
?>