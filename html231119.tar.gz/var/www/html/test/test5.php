<?php
    $arr = array("ng"=>0, "nc"=>3);
    $fpath = './data/bsiterator';
    $f = fopen($fpath,"r") or "er";
    if($f == "er"){
        echo "Unable to access file";
    }
    else{
        // $str = fread($f,filesize($fpath));
        // echo $str;
        if (file_get_contents($fpath) == "") {
            file_put_contents($fpath, serialize($arr));
            echo "write";
        } else {
            $a = file_get_contents($fpath);
            echo $a . "<br>";
            var_dump(unserialize($a));
        }
        // echo var_dump(json_decode($str));
        // echo var_dump((array)json_decode($str));
    }
    // file_put_contents($fpath, "dsb");
?>