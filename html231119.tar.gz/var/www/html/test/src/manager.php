<?php

require_once "./src/mysql.php";

class Manager {

    private $db;
    private $sql = "";
    public $err = FALSE;

    function __construct() {
        $this->db = new Database;
        // echo var_dump($this->$db);
        if ($this->db->connerr === TRUE) {
            $this->err = TRUE;
        } else {
            $this->err = FALSE; // 如果连接没有错误，确保将 $this->err 设置为 FALSE
        }
    }

    function get_sum () {
        $this->sql = "SELECT `value` FROM `Basic` WHERE id=2";
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            $this->err = TRUE;
            // var_dump($this->err);
            // return $result["msg"];
        }

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = $result->fetch_assoc()) {
                return $row["value"];
            }
        } else {
            $this->err = TRUE;
            // var_dump($this->err);
            return null;
        }
    
        return null; // 在没有匹配的情况下，明确返回 null 或适当的默认值
    }

    function get_round () {
        $this->sql = "SELECT `value` FROM `Basic` WHERE id=1";
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            $this->err = TRUE;
            // var_dump($this->err);
            // return $result["msg"];
        }

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = $result->fetch_assoc()) {
                return $row["value"];
            }
        } else {
            $this->err = TRUE;
            // var_dump($this->err);
            return null;
        }
    
        return null; // 在没有匹配的情况下，明确返回 null 或适当的默认值
    }

    function set_sum($sum) { //int, int
        $str = (string)$sum;
        $this->sql = "UPDATE `Basic` SET `value`='" . $str . "' WHERE id=2";
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            return null;
        } else {
            return TRUE;
        }
    }

    function set_round($round) { //int, int
        $str = (string)$round;
        $this->sql = "UPDATE `Basic` SET `value`='" . $str . "' WHERE id=1";
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            return null;
        } else {
            return TRUE;
        }
    }

    function __destruct() {
        //nothing to do
    }
}
?>