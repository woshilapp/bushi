<?php
//array func

function in_array_num ($arr, $any) {
    $sum = 0;
    foreach ($arr as $k => $v) {
        if ($v === $any) {
            $sum += 1;
        }
    }
    return $sum;
}

function pop_array_val ($arr, $any) {
    $find = FALSE;
    $narr = [];
    foreach ($arr as $k => $v) {
        if ($v === $any) {
            if ($find) {
                array_push($narr, $v);
            } else {
                $find = TRUE;
            }
        } else {
            array_push($narr, $v);
        }
    }
    return $narr;
}
?>