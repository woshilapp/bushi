<?php

require_once "./src/mysql.php";
require_once "./src/manager.php";

class LogManager {

    private $db;
    private $m;
    private $sql = "";
    public $err = FALSE;

    function __construct() {
        $this->db = new Database;
        $this->m = new Manager;
        // echo var_dump($this->$db);
        if ($this->db->connerr === TRUE) {
            $this->err = TRUE;
        } else {
            $this->err = FALSE; // 如果连接没有错误，确保将 $this->err 设置为 FALSE
        }
    }

    function get_logs($type) { //int
        switch ($type) {
            case 1:
                $this->sql = "SELECT id, sum, round, cgroup, bgroup, coins, `value` FROM `Logs` WHERE `type`=" . (string)$type;
                break;
            case 2:
                $this->sql = "SELECT id, sum, round, cgroup, `value` FROM `Logs` WHERE `type`=" . (string)$type;
                break;
            case 3:
                $this->sql = "SELECT id, cgroup, bgroup, coins, `value` FROM `Logs` WHERE `type`=" . (string)$type;
                break;
            case 4:
                $this->sql = "SELECT id, cgroup, bgroup, `value` FROM `Logs` WHERE `type`=" . (string)$type;
                break;
            default:
                return null;
        }

        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            $this->err = TRUE;
        }

        if ($result && mysqli_num_rows($result) > 0) {
            switch ($type) {
                case 1:
                    $darr = []; //data array
                    while ($row = $result->fetch_assoc()) {
                        array_push($darr, array("id"=>$row["id"], "sum"=>$row["sum"], "round"=>$row["round"], "cgroup"=>$row["cgroup"], "bgroup"=>$row["bgroup"], "coins"=>$row["coins"], "value"=>$row["value"]));
                    }
                    return $darr;
                    break;
                case 2:
                    $darr = []; //data array
                    while ($row = $result->fetch_assoc()) {
                        array_push($darr, array("id"=>$row["id"], "sum"=>$row["sum"], "round"=>$row["round"], "cgroup"=>$row["cgroup"], "value"=>$row["value"]));
                    }
                    return $darr;
                    break;
                case 3:
                    $darr = []; //data array
                    while ($row = $result->fetch_assoc()) {     
                        array_push($darr, array("id"=>$row["id"], "cgroup"=>$row["cgroup"], "bgroup"=>$row["bgroup"], "coins"=>$row["coins"], "value"=>$row["value"]));
                    }
                    return $darr;
                    break;
                case 4:
                    $darr = []; //data array
                    while ($row = $result->fetch_assoc()) {
                        array_push($darr, array("id"=>$row["id"], "cgroup"=>$row["cgroup"], "bgroup"=>$row["bgroup"], "value"=>$row["value"]));
                    }
                    return $darr;
                    break;
            }
            
        } else {
            $this->err = TRUE;
            return null;
        }
    
        return null;
    }

    function new_log($type, $cgroup, $bgroup, $coins, $value) { //int, int, int, int, string
        $count = 0;
        $rr = $this->db->query("SELECT * FROM Logs");
        if (is_array($rr)) {
            $this->err = TRUE;
            return null;
        }

        $count = mysqli_num_rows($rr);

        switch ($type) {
            case 1:
                $this->sql = "INSERT INTO `Logs` SET id=" . (string)$count . ", type=1" . ", sum=" . (string)$this->m->get_sum() . ", round=" . (string)$this->m->get_round() . ", cgroup=" . (string)$cgroup . ", bgroup=" . (string)$bgroup . ", coins=" . (string)$coins . ", `value`='" . $value . "'";
                break;
            case 2:
                $this->sql = "INSERT INTO `Logs` SET id=" . (string)$count . ", type=2" . ", sum=" . (string)$this->m->get_sum() . ", round=" . (string)$this->m->get_round() . ", cgroup=" . (string)$cgroup . ", bgroup=" . (string)$bgroup . ", coins=" . (string)$coins . ", `value`='" . $value . "'";
                break;
            case 3:
                $this->sql = "INSERT INTO `Logs` SET id=" . (string)$count . ", type=3" . ", sum=" . "0" . ", round=" . "0" . ", cgroup=" . (string)$cgroup . ", bgroup=" . (string)$bgroup . ", coins=" . (string)$coins . ", `value`='" . $value . "'";
                break;
            case 4:
                $this->sql = "INSERT INTO `Logs` SET id=" . (string)$count . ", type=4" . ", sum=" . "0" . ", round=" . "0" . ", cgroup=" . (string)$cgroup . ", bgroup=" . (string)$bgroup . ", coins=" . (string)$coins . ", `value`='" . $value . "'";
                break;
            default:
                return null;
        }

        $result = $this->db->query($this->sql);

        if (is_array($result)) {
            $this->err = TRUE;
            return null;
        } else {
            return TRUE;
        }
    }

    function __destruct() {
        //nothing to do
    }

}
?>