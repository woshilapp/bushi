<?php
class Database {
    private $servername = "localhost";
    private $username = "user";
    private $password = "admin123";
    private $dbname = "test"; //config
    private $conn;
    public $connerr = FALSE;

    function __construct() {
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
        
        if ($this->conn->connect_error) {
            $this->connerr = TRUE;
        } 
    }

    function query($sql){
        try {
            // 执行SQL查询
            $result = $this->conn->query($sql);
    
            // 检查查询是否成功
            if (!$result) {
                // 查询失败，抛出异常
                throw new Exception("Error: " . $sql . "<br>" . $this->conn->error);
            }
    
            // 查询成功，返回结果集
            return $result;
        } catch (Throwable $t) {
            // 捕获异常并返回错误消息
            return ["err"=>TRUE,"msg"=>$t->getMessage()];
        
        } catch (Exception $e) {
            // 捕获异常并返回错误消息
            return ["err"=>TRUE,"msg"=>$e->getMessage()];
            // return $e->getMessage();
            }
    }

    function __destruct() {
        $this->conn->close();
    }
}

// $sql = "INSERT INTO `Group` (`id`, `card`, `coins`, `catch`, `bcatch`, `cards`) 
// VALUES ('1', 'J', '10', '0', '0', '1,2,3,4,5,6,7,8')";

// $sb = ['J','J','J','Q','Q','Q','K','K'];

// for($i = 0;$i<8;$i++){
//     $sql = "UPDATE `Group` SET `card` = '" . $sb[$i] . "' WHERE `Group`.`id` = " . (string)$i+1 . "";
//     try{
//         if ($conn->query($sql) === TRUE) {
//             echo "新记录插入成功";
//         }
//     }
//     catch (Throwable $t) {
//         echo $t;
//     } catch (Exception $e) {
//         echo $e;
//     }
// }
?>