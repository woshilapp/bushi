<?php

require_once "./src/mysql.php";

class GroupManager {

    private $db;
    private $sql = "";
    public $err = FALSE;

    function __construct() {
        $this->db = new Database;
        // echo var_dump($this->$db);
        if ($this->db->connerr === TRUE) {
            $this->err = TRUE;
        } else {
            $this->err = FALSE; // 如果连接没有错误，确保将 $this->err 设置为 FALSE
        }
    }

    function get_card($group) {
        $this->sql = "SELECT id, card FROM `Group`";
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            $this->err = TRUE;
            // var_dump($this->err);
            // return $result["msg"];
        }

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = $result->fetch_assoc()) {
                if ($row["id"] == $group) {
                    return $row["card"];
                }
            }
        } else {
            $this->err = TRUE;
            return null;
        }
    
        return null; // 在没有匹配的情况下，明确返回 null 或适当的默认值
    }
    
    function set_card($group, $card) { //int, string
        $this->sql = "UPDATE `Group` SET `card`='" . $card . "' WHERE id=" . (string)$group;
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            return null;
        } else {
            return TRUE;
        }
    }

    function get_cards ($group) { //int
        $this->sql = "SELECT id, cards FROM `Group` WHERE id=" . (string)$group;
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            $this->err = TRUE;
            // var_dump($this->err);
            // return $result["msg"];
        }

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = $result->fetch_assoc()) {
                $ctext = $row["cards"];
                return explode(",", $ctext);
            }
        } else {
            $this->err = TRUE;
            var_dump($this->err);
        }
    
        return null; // 在没有匹配的情况下，明确返回 null 或适当的默认值
    }

    function get_cards_num ($group, $card) { //int, int
        $arr = $this->get_cards($group);
        $sum = 0;
        if (is_array($arr)) {
            foreach ($arr as $k => $v) {
                if ($v == $card) {
                    $sum += 1;
                }
            }
            return $sum;
        } else {
            return null;
        }
    }

    function pop_card ($group, $card) { //int, int
        if ($this->get_cards_num($group, $card) < 1) {
            return null;
        } else {
            $str = "";
            foreach(pop_array_val($this->get_cards($group), (string)$card) as $k => $v) {
                $str = $str . "," . (string)$v;
            }
            $str = substr($str, 1);
            $this->sql = "UPDATE `Group` SET cards='" . $str . "' WHERE id=" . (string)$group;
            $result = $this->db->query($this->sql);
            if (is_array($result)) {
                return null;
            } else {
                return TRUE;
            }
        }
    }

    function add_card ($group, $card) { //int, int
        $arr = $this->get_cards($group);
        $str = "";
        array_push($arr,(string)$card);
        sort($arr);
        foreach ($arr as $k => $v) {
            $str = $str . "," . (string)$v;
        }
        $str = substr($str, 1);
        $this->sql = "UPDATE `Group` SET cards='" . $str . "' WHERE id=" . (string)$group;
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            return null;
        } else {
            return TRUE;
        }
    }

    function get_coin($group) { //int
        $this->sql = "SELECT id, coins FROM `Group` WHERE id=" . (string)$group;
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            $this->err = TRUE;
            return null;
        }

        return $result->fetch_assoc()["coins"];

    }

    function get_catch($group) { //int
        $this->sql = "SELECT id, `catch` FROM `Group` WHERE id=" . (string)$group;
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            $this->err = TRUE;
            return null;
        }

        return $result->fetch_assoc()["catch"];

    }

    function get_bcatch($group) { //int
        $this->sql = "SELECT id, `bcatch` FROM `Group` WHERE id=" . (string)$group;
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            $this->err = TRUE;
            return null;
        }

        return $result->fetch_assoc()["bcatch"];

    }

    function set_catch($group, $catch) { //int, int
        $str = (string)$catch;
        $this->sql = "UPDATE `Group` SET `catch`='" . $str . "' WHERE id=" . (string)$group;
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            return null;
        } else {
            return TRUE;
        }
    }

    function set_bcatch($group, $catch) { //int, int
        $str = (string)$catch;
        $this->sql = "UPDATE `Group` SET `bcatch`='" . $str . "' WHERE id=" . (string)$group;
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            return null;
        } else {
            return TRUE;
        }
    }

    function add_coin($group, $coin) { //int, int
        $str = (string)((int)$this->get_coin($group) + $coin);
        $this->sql = "UPDATE `Group` SET coins='" . $str . "' WHERE id=" . (string)$group;
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            return null;
        } else {
            return TRUE;
        }
    }

    function reduce_coin($group, $coin) { //int, int
        if ((int)$this->get_coin($group) < $coin) {
            return null;
        }

        $str = (string)((int)$this->get_coin($group) - $coin);
        $this->sql = "UPDATE `Group` SET coins='" . $str . "' WHERE id=" . (string)$group;
        $result = $this->db->query($this->sql);
        if (is_array($result)) {
            return null;
        } else {
            return TRUE;
        }
    }

    function gen_cards() {
        $arr = ['J','J','J','Q','Q','Q','K','K','K'];
        shuffle($arr);

        for ($i = 1;$i <= 8;$i++) {
            $this->set_card($i, $arr[$i]);
        }
    }

    function __destruct() {
        //nothing to do
    }
}
?>