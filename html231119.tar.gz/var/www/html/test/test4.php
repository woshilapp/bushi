<?php
require "./src/mysql.php";
// $sql = "UPDATE `Group` SET cards='1,2,3,4,5,6,7,8' WHERE id=1";
$sql = $_GET["q"];
$mysql = new Database;
if ($mysql->connerr !== TRUE) {
    echo "connected" . "<br>";
}
$result = $mysql->query($sql);
echo var_dump($result) . "<br>";
var_dump($result->fetch_assoc());

?>