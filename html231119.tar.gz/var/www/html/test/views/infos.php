<?php

    /*permission: 
        0 sum, round, catch, coins
        1 +(self)card, cards, bcatch
        2 +bcatch, cards
        3 all
    */

    require_once "./src/manager.php";
    require_once "./src/groupmanager.php";

    $GLOBALS["m"] = new Manager();
    $GLOBALS["gm"] = new GroupManager();

    function groups_coins_arr() {
        $coinarr = [];

        for ($i=1;$i<=8;$i++) {
            $coinarr[$i] = $GLOBALS["gm"]->get_coin($i);
        }

        return $coinarr;
    }

    function groups_catch_arr() {
        $carr = [];

        for ($i=1;$i<=8;$i++) {
            $carr[$i] = $GLOBALS["gm"]->get_catch($i);
        }

        return $carr;
    }

    function groups_bcatch_arr() {
        $carr = [];

        for ($i=1;$i<=8;$i++) {
            $carr[$i] = $GLOBALS["gm"]->get_bcatch($i);
        }

        return $carr;
    }

    function groups_card_arr() {
        $carr = [];

        for ($i=1;$i<=8;$i++) {
            $carr[$i] = $GLOBALS["gm"]->get_card($i);
        }

        return $carr;
    }

    function groups_cards_arr() {
        $carr = [];

        for ($i=1;$i<=8;$i++) {
            $carr[$i] = $GLOBALS["gm"]->get_cards($i);
        }

        return $carr;
    }

    if ($_SESSION["per"] == 0) {
        $things = [];
        $things["sum"] = $GLOBALS["m"]->get_sum();
        $things["round"] = $GLOBALS["m"]->get_round();
        $things["coins"] = groups_coins_arr();
        $things["catch"] = groups_catch_arr();
        // var_dump($things);
        echo json_encode($things);

    } else if ($_SESSION["per"] == 1) {
        $things = [];
        $things["sum"] = $GLOBALS["m"]->get_sum();
        $things["round"] = $GLOBALS["m"]->get_round();
        $things["coins"] = groups_coins_arr();
        $things["catch"] = groups_catch_arr();
        $things["bcatch"] = $GLOBALS["gm"]->get_bcatch($_SESSION["gp"]);
        $things["card"] = $GLOBALS["gm"]->get_card($_SESSION["gp"]);
        $things["cards"] = $GLOBALS["gm"]->get_cards($_SESSION["gp"]);
        // var_dump($things);
        echo json_encode($things);

    } else if ($_SESSION["per"] == 2) {
        $things = [];
        $things["sum"] = $GLOBALS["m"]->get_sum();
        $things["round"] = $GLOBALS["m"]->get_round();
        $things["coins"] = groups_coins_arr();
        $things["catch"] = groups_catch_arr();
        $things["bcatch"] = groups_bcatch_arr();
        $things["cards"] = groups_cards_arr();
        // var_dump($things);
        echo json_encode($things);

    } else if ($_SESSION["per"] == 3) {
        $things = [];
        $things["sum"] = $GLOBALS["m"]->get_sum();
        $things["round"] = $GLOBALS["m"]->get_round();
        $things["coins"] = groups_coins_arr();
        $things["catch"] = groups_catch_arr();
        $things["bcatch"] = groups_bcatch_arr();
        $things["card"] = groups_card_arr();
        $things["cards"] = groups_cards_arr();
        // var_dump($things);
        echo json_encode($things);

    } else {
        echo "what are u fking doing?";
    }
?>