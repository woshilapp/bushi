<?php
    if (isset($_SESSION["pass"])) {
        echo "TRUE";
    } else {
        echo "FALSE";
    }
?>