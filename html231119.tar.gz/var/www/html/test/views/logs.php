<?php

require_once "./src/logmanager.php";

/*
permissions:
    0:t1,2
    1:+t3,4(self)
    2:+3
    3:all
*/

$GLOBALS["lm"] = new LogManager();

if ($_SESSION["per"] == 0) {
    $things = [];
    $things["1"] = $GLOBALS["lm"]->get_logs(1);
    $things["2"] = $GLOBALS["lm"]->get_logs(2);
    echo json_encode($things);
} else if ($_SESSION["per"] == 1) {
    $arr3 = [];
    $arr4 = [];

    foreach ($GLOBALS["lm"]->get_logs(3) as $k => $v) {
        if ($v["cgroup"] == $_SESSION["gp"] or $v["bgroup"] == $_SESSION["gp"]) {
            array_push($arr3, $v);
        }
    }

    foreach ($GLOBALS["lm"]->get_logs(4) as $k => $v) {
        if ($v["cgroup"] == $_SESSION["gp"] or $v["bgroup"] == $_SESSION["gp"]) {
            array_push($arr4, $v);
        }
    }

    $things = [];
    $things["1"] = $GLOBALS["lm"]->get_logs(1);
    $things["2"] = $GLOBALS["lm"]->get_logs(2);
    $things["3"] = $arr3;
    $things["4"] = $arr4;
    echo json_encode($things);
} else if ($_SESSION["per"] == 2) {
    $things = [];
    $things["1"] = $GLOBALS["lm"]->get_logs(1);
    $things["2"] = $GLOBALS["lm"]->get_logs(2);
    $things["3"] = $GLOBALS["lm"]->get_logs(3);
    // $things["4"] = $arr4;
    echo json_encode($things);
} else if ($_SESSION["per"] == 3) {
    $things = [];
    $things["1"] = $GLOBALS["lm"]->get_logs(1);
    $things["2"] = $GLOBALS["lm"]->get_logs(2);
    $things["3"] = $GLOBALS["lm"]->get_logs(3);
    $things["4"] = $GLOBALS["lm"]->get_logs(4);
    echo json_encode($things);
} else {
    echo "what the fk you doing?";
}

?>