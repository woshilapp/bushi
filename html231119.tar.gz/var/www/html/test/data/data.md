permissions:
    0:only read
    1:group master
    2:bushi //1 and 2 is special
    3:operator

user.json:
    The file of users info
    
    example : "abc" : ["123",0]

    "abc" : username
    [...] : data array
    [
        "123" : password
        0 : permission
    ]
    if permission = 1, data array = ["pw",1,1] //last 1 is group id

bsiterator:
    the array of bushi,the Serialized Data
    "coins" : bushi reduce coins
    "nextg" : next bushi group


ttgroup:
    a array,the Serialized Data of eliminated groups

Logs:
    types:
        //all types have value(text)
        bushi:
            bushi_do: //1(type num)
                sum, round, cgroup, bgroup, coins
            bushi_pass: //2
                sum, round, cgroup
        actions:
            coins: //3
                cgroup, bgroup, coins
            cards: //4
                cgroup, bgroup
        login:
            //maybe come